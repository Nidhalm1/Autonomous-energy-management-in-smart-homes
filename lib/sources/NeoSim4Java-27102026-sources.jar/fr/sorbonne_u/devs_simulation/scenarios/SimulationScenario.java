package fr.sorbonne_u.devs_simulation.scenarios;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to provide a
// basic component programming model to program with components
// distributed applications in the Java programming language.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import fr.sorbonne_u.devs_simulation.models.AtomicModel;
import fr.sorbonne_u.devs_simulation.models.events.EventI;
import fr.sorbonne_u.devs_simulation.models.time.Duration;
import fr.sorbonne_u.devs_simulation.models.time.Time;
import fr.sorbonne_u.devs_simulation.exceptions.NeoSim4JavaException;;

// -----------------------------------------------------------------------------
/**
 * The class <code>SimulationScenario</code> implements a scenario to be
 * executed by simulators defined in the DEVS simulation framework NeoSim4Java. 
 *
 * <p><strong>Description</strong></p>
 * 
 * <p>
 * A simulation scenario describe a simulation run were some of the actions
 * taken by simulation models are imposed by the scenario. Hence, at the heart
 * of a scenario, there is a sequence of simulation steps performed by a set of
 * simulation models included in the simulator and identified by their URI. Each
 * simulation step is defined by the class {@code SimulationStep}.
 * </p>
 * <p>
 * Each step represents an action to be taken by some simulation model as an
 * internal transition, perhaps exporting some external events. Steps are
 * provided by an array of {@code SimulationStep} instances that must be ordered
 * by ascending times of occurrence. To help constructing complex scenarios
 * intertwining actions performed by different simulation models, the array
 * of steps contains all of the actions in a scenario, including all simulation
 * models the scenario will involve. However, the execution of the scenario
 * makes advances per simulation models.
 * </p>
 * <p>
 * As a scenario is a simulation run, some set up may be necessary, mainly to
 * define simulation run parameters for the simulation models appearing in
 * the simulator. {@code SimulationScenario} proposes two set up types of
 * functions, among which one must be provide at creation time:
 * </p>
 * <ul>
 * <li>a function of two parameters taking as arguments the reference to the
 *   simulator and the scenario about to be executed, and</li>
 * <li>a function of three parameters taking the same two arguments plus
 *   a map of run parameters already created and that must be initialised
 *   on the simulator models.</li>
 * </ul>
 * <p>
 * Optional beginning and ending messages can also be provided. To execute a
 * scenario, the standard DEVS protocol methods in models having steps to be
 * performed call this class methods. First, in the class implementing the
 * simulation run, the simulator must be constructed as usual and then the
 * set up function provided by the scenario must be called. Then, models
 * that do not perform steps defined in the scenario executes as usual. Models
 * that must perform steps defined in the scenario uses the following methods
 * of this class:
 * </p>
 * <ul>
 * <li>The methods {@code setUpSimulator} are called to set up the simulation
 *   run parameters and other configuration options.</li>
 * <li>The methods {@code getStartTime()}, to retrieve the simulated start time,
 *   and {@code getEndTime()}, to retrieve the simulated end time, to start the
 *   simulation by calling the chosen start method of NeoSim4Java.</li>
 * <li>Models having to perform steps can retrieve the time of their next step
 *   by calling the methods {@code simulatedTimeOfNextStep} or
 *   {@code simulatedDelayToNextStep}, typically in their method
 *   {@code timeAdvance} to know whether their next internal transition in their
 *   next step or another internal transition.</li>
 * <li>When a model must execute a step, the method {@code generateOutput}
 *   is called in their {@code output} method to generate and export the
 *   external events of this step.</li>
 * <li>Next, the method {@code performInternalTransition} is called by their
 *   method {@code userDefinedInternalTransition} to perform the internal
 *   transition of the step.</li>
 * <li>Finally, the method {@code advanceToNextStep} is called to advance the
 *   scenario for that model to its next step. The method
 *   {@code scenarioTerminated} allows to check if the scenario is terminated
 *   for the model.</li>
 * </ul>
 * 
 * <p><strong>Implementation Invariants</strong></p>
 * 
 * <pre>
 * invariant	{@code steps != null && steps.length > 0}
 * invariant	{@code participantsURIs != null && participantsURIs.size() > 0}
 * invariant	{@code (!(setUp2 != null && setUp3 != null) && !(setUp2 == null && setUp3 == null))}
 * invariant	{@code startTime != null}
 * invariant	{@code endTime != null}
 * invariant	{@code startTime.lessThan(endTime)}
 * invariant	{@code nextSteps != null}
 * invariant	{@code nextSteps.size() == participantsURIs.size()}
 * invariant	{@code nextSteps.keySet().stream().allMatch(uri -> participantsURIs.contains(uri))}
 * invariant	{@code nextSteps.values().stream().allMatch(index -> index >= 0 && index <= steps.length)}
 * </pre>
 * 
 * <p><strong>Invariants</strong></p>
 * 
 * <pre>
 * invariant	{@code true}	// no more invariant
 * </pre>
 * 
 * <p>Created on : 2025-10-20</p>
 * 
 * @author	<a href="mailto:Jacques.Malenfant@lip6.fr">Jacques Malenfant</a>
 */
public class			SimulationScenario
{
	// -------------------------------------------------------------------------
	// Constants and variables
	// -------------------------------------------------------------------------

	/** when true, trace the scenario.										*/
	public static boolean					VERBOSE = true;
	/** when true, print debugging information on the scenario.				*/
	public static boolean					DEBUG = true;

	/** message to be print at the beginning of the scenario when
	 *  {@code VERBOSE} is true.											*/
	protected final String					beginningMessage;
	/** message to be print at the end of the scenario when {@code VERBOSE}
	 *  is true.															*/
	protected final String					endingMessage;

	/** the steps in the scenario.											*/
	protected final SimulationStep[]		steps;
	/** URIs of the entities performing simulation steps in this scenario.	*/
	protected final Set<String>				participantsURIs;
	/** indexes if the next steps for every simulation models.				*/
	protected final Map<String, Integer>	nextSteps;

	/** start time of the simulation run in simulated time.					*/
	protected final Time					startTime;
	/** end time of the simulation run in simulated time.					*/
	protected final Time					endTime;
	/** add the scenario run parameters to its argument.					*/
	protected final BiConsumer<SimulationScenario,
							   Map<String, Object>>
											addToRunParameters;

	// -------------------------------------------------------------------------
	// Constructors
	// -------------------------------------------------------------------------

	/**
	 * create a scenario maybe including simulation steps with the given
	 * messages, set up and steps.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code steps != null && steps.length > 0}
	 * pre	{@code startTime != null}
	 * pre	{@code endTime != null}
	 * pre	{@code startTime.lessThan(endTime)}
	 * pre	{@code addToRunParameters != null}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param startTime				start time of the simulation run in simulated time.
	 * @param endTime				end time of the simulation run in simulated time.
	 * @param addToRunParameters	function that adds scenario specific run parameters to an existing map of run parameters.
	 * @param steps					steps in the scenario.
	 */
	public				SimulationScenario(
		Time startTime,
		Time endTime,
		BiConsumer<SimulationScenario, Map<String, Object>>
														addToRunParameters,
		SimulationStep[] steps
		)
	{
		this(null, null, startTime, endTime, addToRunParameters, steps);
	}

	/**
	 * create a simulation scenario maybe including simulation steps with the given
	 * messages, set up and steps.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code steps != null && steps.length > 0}
	 * pre	{@code startTime != null}
	 * pre	{@code endTime != null}
	 * pre	{@code startTime.lessThan(endTime)}
	 * pre	{@code addToRunParameters != null}
	 * pre	{@code clockURI != null && !clockURI.isEmpty()}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param beginingMessage		message to be output on sysout at the beginning of the scenario.
	 * @param endingMessage			message to be output on sysout at the end of the scenario.
	 * @param startTime				start time of the simulation run in simulated time.
	 * @param endTime				end time of the simulation run in simulated time.
	 * @param addToRunParameters	function that adds scenario specific run parameters to an existing map of run parameters.
	 * @param steps					simulation steps in the scenario.
	 */
	public				SimulationScenario(
		String beginingMessage,
		String endingMessage,
		Time startTime,
		Time endTime,
		BiConsumer<SimulationScenario, Map<String, Object>> addToRunParameters,
		SimulationStep[] steps
		)
	{
		super();

		// Preconditions checking
		assert	steps != null && steps.length > 0 :
				new NeoSim4JavaException("steps != null && steps.length > 0");
		assert	startTime != null :
				new NeoSim4JavaException("startTime != null");
		assert	endTime != null :
				new NeoSim4JavaException("endTime != null");
		assert	startTime.lessThan(endTime) :
				new NeoSim4JavaException("startTime.lessThan(endTime)");
		assert	addToRunParameters != null :
				new NeoSim4JavaException("addToRunParameters != null");
		assert	ordered(steps) :
				new NeoSim4JavaException("ordered(steps)");

		this.beginningMessage = beginingMessage;
		this.endingMessage = endingMessage;
		this.steps = steps;

		this.participantsURIs = new HashSet<>();
		this.nextSteps = new HashMap<>();
		for (int i = 0 ; i < steps.length ; i++) {
			String uri = steps[i].getPerformingEntityURI();
			this.participantsURIs.add(uri);
			if (!this.nextSteps.containsKey(uri)) {
				// the first step in which the model with this URI appears in
				this.nextSteps.put(uri, i);
			}
		}

		this.startTime = startTime;
		this.endTime = endTime;
		this.addToRunParameters = addToRunParameters;
	}

	// -------------------------------------------------------------------------
	// Methods common to all types of steps
	// -------------------------------------------------------------------------

	/**
	 * return true if the steps in {@code steps} appear in increasing order
	 * of time of occurrence, otherwise false.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code steps != null && steps.length > 0}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param steps	steps in a scenario.
	 * @return		true if the steps in {@code steps} appear in increasing order of instant of occurrence, otherwise false.
	 */
	public static boolean	ordered(SimulationStep[] steps)
	{
		assert	steps != null && steps.length > 0 :
				new NeoSim4JavaException("steps != null && steps.length > 0");

		boolean ret = true;
		Time old = steps[0].getTimeOfOccurrence();
		for (int i = 1 ; ret && i < steps.length ; i++) {
			Time current = steps[i].getTimeOfOccurrence();
			ret &= old.lessThanOrEqual(current);
			old = current;
		}
		return ret;
	}

	/**
	 * return the message to be output at the beginning of the scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @return	the message to be output at the beginning of the scenario.
	 */
	public String		beginMessage()
	{
		return this.beginningMessage;
	}

	/**
	 * return the message to be output at the end of the scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @return	the message to be output at the end of the scenario.
	 */
	public String		endMessage()
	{
		return this.endingMessage;
	}

	/**
	 * return the simulated start time of this scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code return != null}
	 * </pre>
	 *
	 * @return	the simulated start time of this scenario.
	 */
	public Time			getStartTime()
	{
		return this.startTime;
	}

	/**
	 * return the simulated end time of this scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code return != null}
	 * </pre>
	 *
	 * @return	the simulated end time of this scenario.
	 */
	public Time			getEndTime()
	{
		return this.endTime;
	}

	// -------------------------------------------------------------------------
	// Methods used in simulation steps
	// -------------------------------------------------------------------------

	/**
	 * add the run parameters for this scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code simParams != null}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param simParams	map of simulation run parameters.
	 */
	public void			addToRunParameters(
		Map<String, Object> simParams
		)
	{
		assert	simParams != null :
				new NeoSim4JavaException("simParams != null");

		this.addToRunParameters.accept(this, simParams);
	}

	/**
	 * return true if {@code uri} is the URI of an entity performing some
	 * actions in this scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param uri	an URI.
	 * @return		true if {@code uri} is the URI of an entity performing some actions in this scenario.
	 */
	public boolean		entityAppearsIn(String uri)
	{
		if (uri == null) {
			return false;
		} else {
			return this.participantsURIs.contains(uri);
		}
	}

	/**
	 * return the index of the next step in the scenario that the entity which
	 * URI is {@code uri} must perform or an index out of the range of the
	 * steps in this scenario if the entity has performed all of its steps.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code entityAppearsIn(uri)}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param uri	URI of an entity that must perform steps in this scenario.
	 * @return		the index of the next step in the scenario that the model must perform.
	 */
	protected int		findNextStepIndex(String uri)
	{
		assert	this.entityAppearsIn(uri) :
				new NeoSim4JavaException(
						"Precondition violation: entityAppearsIn(uri)");

		int ret = this.nextSteps.get(uri) + 1;
		for (int i = ret ; i < this.steps.length ; i++) {
			if (!uri.equals(
					this.steps[i].getPerformingEntityURI())) {
				ret++;
			} else {
				break;
			}
		}
		return ret;
	}

	/**
	 * return the instant of occurrence of the next step in this scenario for
	 * the entity which URI is {@code uri}.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code m != null && atomicModelAppearsIn(m.getURI())}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param uri	URI of an entity that must perform steps in this scenario.
	 * @return		the time of occurrence of the next step in this scenario for the entity which URI is {@code uri}.
	 */
	public Time			getTimeOfNextStep(String uri)
	{
		assert	this.entityAppearsIn(uri) :
				new NeoSim4JavaException("entityAppearsIn(uri)");

		return this.steps[this.nextSteps.get(uri)].getTimeOfOccurrence();
	}

	/**
	 * return true if the entity which URI is {@code uri} has not terminated its
	 * actions in this scenario yet.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code entityAppearsIn(uri)}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param uri	URI of an entity that must perform steps in this scenario.
	 * @return		true if the entity has not terminated its actions in this scenario yet.
	 */
	public boolean		scenarioTerminated(String uri)
	{
		if (this.entityAppearsIn(uri)) {
			return this.nextSteps.get(uri) >= this.steps.length;
		} else {
			return true;
		}
	}

	/**
	 * advance to the next step in this scenario for the entity which URI
	 * is {@code uri}.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code entityAppearsIn(uri)}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param uri	URI of an entity that must perform steps in this scenario.
	 */
	public void			advanceToNextStep(String uri)
	{
		assert	this.entityAppearsIn(uri) :
				new NeoSim4JavaException(
						"Precondition violation: entityAppearsIn(uri)");

		this.nextSteps.put(uri, this.findNextStepIndex(uri));
	}

	/**
	 * return the simulated time at which the next step for {@code m}.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code m != null && atomicModelAppearsIn(m.getURI())}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param m	an atomic model performing actions in the current scenario.
	 * @return	the time at which the next step for {@code m} in simulated time.
	 */
	public Time			simulatedTimeOfNextStep(AtomicModel m)
	{
		if (!this.scenarioTerminated(m.getURI())) {
			return this.getTimeOfNextStep(m.getURI());
		} else {
			return Time.INFINITY;
		}
	}

	/**
	 * return the delay until the next step for {@code m} in simulated time.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code m != null && atomicModelAppearsIn(m.getURI())}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param m	an atomic model performing actions in the current scenario.
	 * @return	the delay until the next step for {@code m} in simulated time.
	 */
	public Duration		simulatedDelayToNextStep(AtomicModel m)
	{
		assert	m != null && this.entityAppearsIn(m.getURI()) :
				new NeoSim4JavaException(
						"m != null && atomicModelAppearsIn(m.getURI())");

		if (!this.scenarioTerminated(m.getURI())) {
			return this.simulatedTimeOfNextStep(m).
											subtract(m.getCurrentStateTime());
		} else {
			return Duration.INFINITY;
		}
	}

	/**
	 * generate the events to be output by the atomic simulation model {@code m}
	 * at the time {@code m.getTimeOfNextEvent()} in this scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code m != null && entityAppearsIn(m.getURI())}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param m		the atomic model on which the internal transition must be executed.
	 * @return		a list of events to be output by the simulation model.
	 */
	public ArrayList<EventI>	generateOutput(AtomicModel m)
	{
		assert	m != null && this.entityAppearsIn(m.getURI()) :
				new NeoSim4JavaException(
						"m != null && entityAppearsIn(m.getURI())");

		SimulationStep step = this.steps[this.nextSteps.get(m.getURI())];
		return step.generateOutput(m);
	}

	/**
	 * perform the next internal transition for the atomic model {@code m} in
	 * this scenario.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code m != null && entityAppearsIn(m.getURI())}
	 * pre	{@code !scenarioTerminated(m.getURI())}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param m		the atomic model on which the internal transition must be executed.
	 */
	public void			performInternalTransition(AtomicModel m)
	{
		assert	m != null && this.entityAppearsIn(m.getURI()) :
				new NeoSim4JavaException(
						"m != null && entityAppearsIn(m.getURI())");
		assert	!this.scenarioTerminated(m.getURI()) :
				new NeoSim4JavaException("!scenarioTerminated(m.getURI())");

		SimulationStep step = this.steps[this.nextSteps.get(m.getURI())];
		step.performInternalTransition(m);
	}
}
// -----------------------------------------------------------------------------
