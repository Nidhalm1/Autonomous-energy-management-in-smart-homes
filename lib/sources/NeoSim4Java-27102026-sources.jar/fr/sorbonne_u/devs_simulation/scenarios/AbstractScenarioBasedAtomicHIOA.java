package fr.sorbonne_u.devs_simulation.scenarios;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to provide a
// basic component programming model to program with components
// distributed applications in the Java programming language.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import java.util.concurrent.TimeUnit;
import fr.sorbonne_u.devs_simulation.exceptions.NeoSim4JavaException;
import fr.sorbonne_u.devs_simulation.hioa.models.AtomicHIOA;
import fr.sorbonne_u.devs_simulation.models.events.EventI;
import fr.sorbonne_u.devs_simulation.models.time.Duration;
import fr.sorbonne_u.devs_simulation.simulators.interfaces.AtomicSimulatorI;
import fr.sorbonne_u.devs_simulation.utils.StandardLogger;
import java.util.ArrayList;

// -----------------------------------------------------------------------------
/**
 * The class <code>AbstractScenarioBasedAtomicHIOA</code> implements the HIOA
 * atomic model methods for models that runs test scenarios.
 *
 * <p><strong>Description</strong></p>
 * 
 * <p>
 * This class is a copy of {@code AbstractScenarioBasedAtomicModel} to pass by
 * the single inheritance constraint of Java.
 * </p>
 * <p>
 * The class defines the methods of the DEVS protocol working hand in hand with
 * an instance of {@code SimulationScenario} composed of instances of
 * {@code SimulationStep} to execute simulation steps for atomic models that
 * must perform steps in the scenario. As an abstract class, it is meant to be
 * extended by the concrete atomic models appearing in the simulator. Hence,
 * atomic models must have been designed to be able to execute simulation steps
 * in scenarios in order to be used that way. The atomic models doing so may
 * either be fully dedicated to the execution of scenarios and then their
 * implementation is very easy, essentially using the methods provided by this
 * abstract class. Or they can also have other internal and external transitions
 * to be implemented, in such case, their DEVS protocol methods must be
 * carefully defined, especially when their own transitions must mix with
 * simulation steps transitions. For example when it must add to the external
 * events to be output by the simulation step some other events of their own not
 * provisioned by the simulation step.
 * </p>
 * 
 * <p><strong>Implementation Invariants</strong></p>
 * 
 * <pre>
 * invariant	{@code true}	// no more invariant
 * </pre>
 * 
 * <p><strong>Invariants</strong></p>
 * 
 * <pre>
 * invariant	{@code true}	// no more invariant
 * </pre>
 * 
 * <p>Created on : 2025-10-21</p>
 * 
 * @author	<a href="mailto:Jacques.Malenfant@lip6.fr">Jacques Malenfant</a>
 */
public abstract class	AbstractScenarioBasedAtomicHIOA
extends		AtomicHIOA
{
	// -------------------------------------------------------------------------
	// Constants and variables
	// -------------------------------------------------------------------------

	private static final long	serialVersionUID = 1L;
	/** when true, leaves a debugging trace of the execution of the model.	*/
	public static boolean		DEBUG = false;

	/** the simulation scenario to be executed.								*/
	private SimulationScenario	scenario;

	// -------------------------------------------------------------------------
	// Constructors
	// -------------------------------------------------------------------------

	/**
	 * create an atomic hybrid input/output model with the given URI (if null,
	 * one will be generated) and to be run by the given simulator using the
	 * given time unit for its clock.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code uri == null || !uri.isEmpty()}
	 * pre	{@code simulatedTimeUnit != null}
	 * pre	{@code simulationEngine == null || !simulationEngine.isModelSet()}
	 * pre	{@code simulationEngine == null || simulationEngine instanceof AtomicEngine}
	 * post	{@code !isDebugModeOn()}
	 * post	{@code getURI() != null && !getURI().isEmpty()}
	 * post	{@code uri == null || getURI().equals(uri)}
	 * post	{@code getSimulatedTimeUnit().equals(simulatedTimeUnit)}
	 * post	{@code getSimulationEngine().equals(simulationEngine)}
	 * </pre>
	 *
	 * @param uri				unique identifier of the model.
	 * @param simulatedTimeUnit	time unit used for the simulation clock.
	 * @param simulationEngine	simulation engine enacting the model.
	 */
	public				AbstractScenarioBasedAtomicHIOA(
		String uri,
		TimeUnit simulatedTimeUnit,
		AtomicSimulatorI simulationEngine
		)
	{
		super(uri, simulatedTimeUnit, simulationEngine);

		this.getSimulationEngine().setLogger(new StandardLogger());
	}

	// -------------------------------------------------------------------------
	// Methods
	// -------------------------------------------------------------------------

	/**
	 * return true if the simulation scenario has been set, otherwise false.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @return	true if the simulation scenario has been set, otherwise false.
	 */
	public boolean		simulationScenarioSet()
	{
		return this.scenario != null;
	}

	/**
	 * set the simulation scenario to be executed.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code scenario != null}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @param scenario	the simulation scenario to be executed.
	 */
	public void			setSimulationScenario(SimulationScenario scenario)
	{
		assert	scenario != null :
				new NeoSim4JavaException(
						"Precondition violation: scenario != null");

		this.scenario = scenario;
	}

	/**
	 * return the simulation scenario under execution.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code simulationScenarioSet()}
	 * post	{@code return != null}
	 * </pre>
	 *
	 * @return	the simulation scenario under execution.
	 */
	public SimulationScenario	getSimulationScenario()
	{
		assert	this.simulationScenarioSet() :
				new NeoSim4JavaException(
						"Precondition violation: simulationScenarioSet()");

		return this.scenario;
	}

	/**
	 * return the time advance to the next internal transition in the simulation
	 * scenario for this model.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code simulationScenarioSet()}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @see fr.sorbonne_u.devs_simulation.models.interfaces.ModelI#timeAdvance()
	 */
	@Override
	public Duration		timeAdvance()
	{
		assert	this.simulationScenarioSet() :
				new NeoSim4JavaException(
						"Precondition violation: simulationScenarioSet()");

		Duration ret = null;
		if (!this.scenario.scenarioTerminated(this.getURI())) {
			ret = this.scenario.simulatedDelayToNextStep(this);
		} else {
			ret = Duration.INFINITY;
		}

		if (DEBUG) {
			this.logMessage(
					"AbstractScenarioBasedAtomicHIOA::timeAdvance returns "
					+ ret);
		}

		return ret;
	}

	/**
	 * generate the output for the current internal transition of this model.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code testScenarioSet()}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @see fr.sorbonne_u.devs_simulation.models.interfaces.AtomicModelI#output()
	 */
	@Override
	public ArrayList<EventI>	output()
	{
		assert	this.simulationScenarioSet() :
				new NeoSim4JavaException(
						"Precondition violation: simulationScenarioSet()");

		ArrayList<EventI> ret = this.scenario.generateOutput(this);

		if (DEBUG) {
			this.logMessage("AbstractScenarioBasedAtomicHIOA::output at "
							+ this.getTimeOfNextEvent() + " returns " + ret);
		}

		return ret;
	}

	/**
	 * perform the next internal transition in the simulation scenario for this
	 * model.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code testScenarioSet()}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @see fr.sorbonne_u.devs_simulation.models.AtomicModel#userDefinedInternalTransition(fr.sorbonne_u.devs_simulation.models.time.Duration)
	 */
	@Override
	public void			userDefinedInternalTransition(Duration elapsedTime)
	{
		assert	this.simulationScenarioSet() :
				new NeoSim4JavaException(
						"Precondition violation: simulationScenarioSet()");

		super.userDefinedInternalTransition(elapsedTime);

		if (DEBUG) {
			this.logMessage(
				"AbstractScenarioBasedAtomicHIOA::"
				+ "userDefinedInternalTransition begins at "
				+ this.getCurrentStateTime()
				+ " with elapsed time " + elapsedTime);
		}

		this.scenario.performInternalTransition(this);
		this.advanceToNextStep();

		if (DEBUG) {
			this.logMessage(
				"AbstractScenarioBasedAtomicHIOA::"
				+ "userDefinedInternalTransition ends at "
				+ this.getCurrentStateTime()
				+ " with time of next step in "
				+ this.scenario.simulatedDelayToNextStep(this));
		}
	}	

	/**
	 * advance to next step in the simulation scenario for model {@code m}.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code simulationScenarioSet()}
	 * pre	{@code getSimulationScenario().entityAppearsInAppearsIn(getURI())}
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 */
	protected void		advanceToNextStep()
	{
		assert	this.simulationScenarioSet() :
				new NeoSim4JavaException("simulationScenarioSet()");
		assert	this.getSimulationScenario().entityAppearsIn(this.getURI()) :
				new NeoSim4JavaException(
						"Precondition violation: getSimulationScenario()."
						+ "entityAppearsInAppearsIn(getURI())");

		if (DEBUG) {
			this.logMessage(
					"AbstractScenarioBasedAtomicHIOA::advanceToNextStep at "
					+ this.getCurrentStateTime());
		}

		if (!this.scenario.scenarioTerminated(this.getURI())) {
			this.scenario.advanceToNextStep(this.getURI());
		}
	}
}
// -----------------------------------------------------------------------------
